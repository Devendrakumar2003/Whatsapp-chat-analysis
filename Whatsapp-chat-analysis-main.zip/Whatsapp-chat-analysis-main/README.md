# Whatsapp-chat-analysis

1.  import all this library

import streamlit as st
import preprocessor, helper
import matplotlib.pyplot as plt
import seaborn as sns

from urlextract import URLExtract
extractor = URLExtract()
from wordcloud import WordCloud
from collections import Counter
import pandas as pd
import emoji

2.  streamlit login

4. to run write on terminal:   streamlit run app.py




